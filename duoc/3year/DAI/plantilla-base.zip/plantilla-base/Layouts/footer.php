<div id="footer">
      <div class="container">
         <p class="text-muted credit">Ejemplo plantilla base para PHP integrada con Boostrap por  <a href="http://www.ecodeup.com">Elivar Largo</a>.</p>
     </div>
 </div>