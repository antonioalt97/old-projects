<nav class="navbar navbar-inverse">
	<div class="container-fluid">
		<div class="navbar-header">			
			<a class="navbar-brand" href="http://localhost/plantilla-base/">
			<span class="glyphicon glyphicon-cloud" aria-hidden="true" ></span>
			Plantilla Base
			</a>
		</div>
			<ul class="nav navbar-nav">
				<li class="active">
					<a href="?menu=registrar">Clientes</a>
				</li>
				<li>
					<a href="?menu=mostrar">Ver Clientes</a>
				</li>
				<li>
					<a href="#">Blog</a>
				</li>
			</ul>
	</div>
</nav>