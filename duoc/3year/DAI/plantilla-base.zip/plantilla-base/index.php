<?php 
	//carga la plantilla con la header y el footer
	require_once('Layouts/layout.php');	

 ?>