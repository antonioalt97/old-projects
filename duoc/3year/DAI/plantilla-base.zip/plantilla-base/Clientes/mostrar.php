<h1>Lista de Clientes</h1>
<div class="container">
	<div class="table-responsive">
		<table class="table table-hover">
			<thead>
				<tr>
					<th>ID</th>
					<th>Alias</th>
					<th>Nombres</th>
					<th>Apellidos</th>
					<th></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td>ID</td>
					<td>ALIAS</td>
					<td>NOMBRES</td>
					<td>APELLIDOS</td>
					<td> <button type="button" class="btn btn-primary">Actualizar</button></td>
					<td><button type="button" class="btn btn-primary" >Eliminar</button></td>
				</tr>
			</tbody>
		</table>
	</div>
</div>