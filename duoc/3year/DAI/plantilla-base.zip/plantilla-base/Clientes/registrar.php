<div class="container">
		  <h2>Registro de Clientes</h2>
		  <form action='#' method='post'>
		  	<div class="form-group">
		      <label for="alias">Alias:</label>
		      <input type="alias" class="form-control" id="alias" name="alias" required="true" placeholder="Ingrese su alias">
		    </div>

		    <div class="form-group">
		      <label for="nombres">Nombres:</label>
		      <input type="nombres" class="form-control" id="nombres" name="nombres" required="true" placeholder="Ingrese sus nombres">
		    </div>

		    <div class="form-group">
		      <label for="email">Email:</label>
		      <input type="email" class="form-control" id="email" name="email" required="true" placeholder="Ingrese su email">
		    </div>
		    <button type="submit" class="btn btn-default">Guardar</button>
		  </form>
</div>